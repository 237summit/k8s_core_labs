# kubernetes-metrics-server

    git clone  https://github.com/237summit/kubernetes-metrics-server.git
    
    cd kubernetes-metrics-server
    
    kubectl create -f .
    
    kubectl get pod -n kube-system
    
    sleep 60
    
    kubectl top nodes
    
    kubectl top pods

^^

